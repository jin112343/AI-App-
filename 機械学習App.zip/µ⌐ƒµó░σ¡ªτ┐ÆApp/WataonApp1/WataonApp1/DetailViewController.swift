//
//  DetailViewController.swift
//  WataonApp1
//
//  Created by Jin Mizou on 2021/01/20.
//

import UIKit
import Charts

class DetailViewController: DemoBaseViewController,IAxisValueFormatter{
  

    //5つの説明
    let activities = ["知的好奇心","誠実性","外向性","協調性","メンタル"]
    
    //ビック5のパーセンテージ
    var percentileArray = [Double]()
    
    //渡ってきたナンバー(ボタンのindex)
    var detailNumber = Int()
    
    var childNameArray1 = [String]()
    var childPercentileArray1 = [Double]()

    var childNameArray2 = [String]()
    var childPercentileArray2 = [Double]()

    var childNameArray3 = [String]()
    var childPercentileArray3 = [Double]()

    var childNameArray4 = [String]()
    var childPercentileArray4 = [Double]()

    var childNameArray5 = [String]()
    var childPercentileArray5 = [Double]()

    var childNameArray6 = [String]()
    var childPercentileArray6 = [Double]()

    
    @IBOutlet weak var chartView: RadarChartView!
    
    let marker = RadarMarkerView.viewFromXib()!
    var xAxis = XAxis()
    var yAxis = YAxis()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        createChartView()
        xAxis = chartView.xAxis
        yAxis = chartView.yAxis
        
        
        // Do any additional setup after loading the view.
    }
    
    func createChartView(){
        
        chartView.chartDescription?.enabled = false
        chartView.webLineWidth = 1
        chartView.innerWebLineWidth = 1
        chartView.webColor = .black
        chartView.innerWebColor = .green
        chartView.webAlpha = 1


        marker.chartView = chartView
        chartView.marker = marker

        xAxis = chartView.xAxis
        xAxis.labelFont = .systemFont(ofSize: 12, weight: .bold)
        xAxis.xOffset = 0
        xAxis.yOffset = 0
        xAxis.valueFormatter = self
        xAxis.labelTextColor = .white
        
        yAxis = chartView.yAxis
        yAxis.labelFont = .systemFont(ofSize: 15, weight: .bold)
        yAxis.labelCount = 6
        yAxis.axisMinimum = 0
        yAxis.axisMaximum = 80
        yAxis.drawLabelsEnabled = false
        
        let l = chartView.legend
        l.horizontalAlignment = .center
        l.verticalAlignment = .top
        l.orientation = .horizontal
        l.drawInside = false
        l.font = .systemFont(ofSize: 15, weight: .bold)
        l.xEntrySpace = 7
        l.yEntrySpace = 5
        l.textColor = .white
        self.updateChartData()
        
        chartView.animate(xAxisDuration: 1.4, yAxisDuration: 1.4, easingOption: .easeInBack)
        

        
    }
    
    //追加
    override func updateChartData() {
          if self.shouldHideData {
              chartView.data = nil
              return
          }
           if percentileArray.count != 0{
              
              self.setChartData()
              
          }
      }

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if percentileArray.count != 0{
            for set in chartView.data!.dataSets{
                set.drawValuesEnabled = !set.drawValuesEnabled
            }
            chartView.setNeedsDisplay()
        }
        
        if percentileArray.count !=  0{
            
            self.setChartData()
        }
    }
    
    
    
    func setChartData(){

        var entries1 = [ChartDataEntry]()
        //5つ要素があるので、5回for文を回す

        if detailNumber == 0{
                
            for i in 0..<6{
                
                entries1.append(RadarChartDataEntry(value: childPercentileArray1[i] * 100))
                
            }

        }
        
        if detailNumber == 1{
                
            for i in 0..<6{
                
                entries1.append(RadarChartDataEntry(value: childPercentileArray2[i] * 100))
                
            }

        }
        
        if detailNumber == 2{
                
            for i in 0..<6{
                
                entries1.append(RadarChartDataEntry(value: childPercentileArray3[i] * 100))
                
            }

        }
        if detailNumber == 3{
                
            for i in 0..<6{
                
                entries1.append(RadarChartDataEntry(value: childPercentileArray4[i] * 100))
                
            }

        }
        
        if detailNumber == 4{
                
            for i in 0..<6{
                
                entries1.append(RadarChartDataEntry(value: childPercentileArray5[i] * 100))
                
            }

        }


        
        
        let set1 = RadarChartDataSet(entries: entries1, label: "ビック5のパーソナリティー特性\n\(activities[detailNumber])の詳細")
        set1.setColor(UIColor(red: 103/255, green: 110/255, blue: 129/255, alpha: 1))
        set1.fillColor = UIColor(red: 103/255, green: 110/255, blue: 129/255, alpha: 1)
        set1.drawFilledEnabled =  true
        set1.fillAlpha = 0.8
        set1.lineWidth = 10
        set1.drawHighlightCircleEnabled = true
        set1.setDrawHighlightIndicators(false)
        
        let data = RadarChartData(dataSets:[set1])
        data.setValueFont(.systemFont(ofSize: 20, weight: .bold))
        data.setDrawValues(true)
        data.setValueTextColor(.white)
        chartView.data = data
        
        
    }

    
    
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
            
        switch detailNumber{
            
        case 0:
            return childNameArray1[Int(value) % childNameArray1.count]
        case 1:
            return childNameArray2[Int(value) % childNameArray2.count]
        case 2:
            return childNameArray3[Int(value) % childNameArray3.count]
        case 3:
            return childNameArray4[Int(value) % childNameArray4.count]
        case 4:
            return childNameArray5[Int(value) % childNameArray5.count]
        default:
            return childNameArray1[Int(value) % childNameArray1.count]
            
        }
        
    }
      
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
