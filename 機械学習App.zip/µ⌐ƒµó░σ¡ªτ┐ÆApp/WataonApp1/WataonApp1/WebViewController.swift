//
//  WebViewController.swift
//  WataonApp1
//
//  Created by Jin Mizou on 2021/01/21.
//

import UIKit
import WebKit
import Lottie


protocol PasteDelegate{
    
    
    func addText(copyedText:String)
    
}

class WebViewController: UIViewController,WKNavigationDelegate,WKUIDelegate {

    @IBOutlet weak var webView: WKWebView!
    
    var pasteDelegate:PasteDelegate?
    var url = "https://logmi.jp/"
    var animationView:AnimationView! = AnimationView()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        
        let urlRequest = URLRequest(url: URL(string: url)!)
        webView.load(urlRequest)
        
        // Do any additional setup after loading the view.
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        //アニメーションをスタート
        startAnimation()
    }
    
    func startAnimation(){
           
           let animation = Animation.named("loading")
           animationView.animation = animation
           animationView.contentMode = .scaleAspectFit
           animationView.frame = CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height)
        animationView.loopMode = .loop
           animationView.backgroundColor = .white
           view.addSubview(animationView)
           animationView.play()
           
           
       }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        
        animationView.removeFromSuperview()
        
    }
    
    
    
    @IBAction func back(_ sender: Any) {
        
        if UIPasteboard.general.string?.isEmpty != true{
            
            pasteDelegate?.addText(copyedText: UIPasteboard.general.string!)
            
        }
        
        dismiss(animated: true, completion: nil)
        
    }
    
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
